import { Component } from '@angular/core';

@Component({
  selector: 'app-plus-mempership',
  templateUrl: './plus-mempership.component.html',
  styleUrls: ['./plus-mempership.component.css']
})
export class PlusMempershipComponent {

}
