import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { Order, UserInterface, UserLoginData } from './user-interface';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  private apiUrl = 'http://localhost:5179/api';

  private currentUserSubject: BehaviorSubject<UserInterface | null> = new BehaviorSubject<UserInterface | null>(null);
  public currentUser: Observable<UserInterface | null> = this.currentUserSubject.asObservable();

 
  constructor(private http: HttpClient, private router: Router) {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      this.currentUserSubject.next(JSON.parse(storedUser));
    }
  }

  getOrdersByUser(userId: number): Observable<any[]> {
    const url = `${this.apiUrl}/UserPage/GetMyOrders?userId=${userId}`;
    return this.http.get<any[]>(url);
  }

  Userlogin(email: string, password: string): Observable<any> {
    const Url = `${this.apiUrl}/Homepage/Userlogin`;
    return this.http.post<UserLoginData>(Url, { email, password });
  }

  getProductDetails(productId:number): Observable<any> {
    //http://localhost:5179/api/UserPage/GetProductByid?productId=1
    const Url = `${this.apiUrl}/UserPage/GetProductByid?productId=${productId}`;
    return this.http.get<any>(Url);
  }

  UserDetail(email:string) : Observable<any>{
    //http://localhost:5179/api/UserPage/ByEmail?email=mohamedimthiyas014%40gmail.com
    const Url = `${this.apiUrl}/UserPage/ByEmail?email=${email}`;
    return this.http.post<UserLoginData>(Url, email);
  }

  createOrder(order: any): Observable<string> {
    const url = `${this.apiUrl}/OrderPage/Order`;
    return this.http.post<string>(url, order, { responseType: 'text' as 'json' });
  }

  updateOrder(orderId: number, updateData: { deliveryAddress: string, contact: string }): Observable<void> {
    //http://localhost:5179/api/UserPage/EditOrder?orderId=1
    const url = `${this.apiUrl}/UserPage/EditOrder?orderId=${orderId}`;
    return this.http.patch<void>(url, updateData);
  }

  cancelOrder(orderId: number): Observable<void> {
    //http://localhost:5179/api/OrderPage/CancelOrder?orderId=1
    const url = `${this.apiUrl}/OrderPage/CancelOrder?orderId=${orderId}`;
    return this.http.put<void>(url,{});
  }


  registerUser(user:any): Observable<any> {
    const Url = `${this.apiUrl}/Homepage/UserRegistration`;
    return this.http.post(Url, user);
  }

  setCurrentUser(userLoginData: UserInterface): void {
    const user: UserInterface = {
      id: userLoginData.id,
      email:userLoginData.email,
      name: userLoginData.name,
      contact: userLoginData.contact
    };
    this.currentUserSubject.next(user);
    localStorage.setItem('currentUser', JSON.stringify(user));
  }

  getCurrentUser(): UserInterface | null {
    return this.currentUserSubject.value;
  }

  isLoggedIn(): boolean {
    return !!this.currentUserSubject.value;
  }

  logout() {
    this.currentUserSubject.next(null);
    localStorage.removeItem('currentUser');
  }
}
