import { Component } from '@angular/core';

@Component({
  selector: 'app-userprocess',
  templateUrl: './userprocess.component.html',
  styleUrls: ['./userprocess.component.css']
})
export class UserprocessComponent {

}
