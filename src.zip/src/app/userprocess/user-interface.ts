export interface UserInterface {
id:number;
email:string;
name:string;
contact:number;
}

export interface UserLoginData{
    email:string;
    password:string;
}
  

export interface Order {
    userId: number;
    productId: number;
    deliveryAddress: string;
    contact: string;
  }