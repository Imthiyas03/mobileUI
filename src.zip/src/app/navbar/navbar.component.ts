import { Component } from '@angular/core';
import { UserService } from '../userprocess/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {

constructor(private userService:UserService,private router:Router){}
toAccout() {
if(this.userService.isLoggedIn()){
  this.router.navigate(['/user-home']);
}
else{
  this.router.navigate(['/userlogin']);
}
}
}
